// sub_650 at 0x650, from libcontroller_guard.so. Approximate pseudo-C from the built-in decompiler.
int64_t sub_650(int64_t x0, int64_t x1, int64_t x2)
{
    x13 = xzr;
    x14 = xzr;
    x1 = *(void*)(x0 + 0x20);
    x2 = 0x40;
    __asm("ubfx x15, x1, #0x3, #0x6");
    x1 += x14;
    x12 = x15 + 0x28;
    x2 -= x15;
    *(void*)(x0 + 0x20) = x1;
    x12 = x0 + x12;
    if (x14 >= x2 /* unsigned */) {
        stack_10[0] = x29; stack_10[1] = x30;
        x11 = 0;
        while (true) {
            w1 = *(void*)(x13 + x11);
            *(void*)(x12 + x11) = w1;
            x11 += 1;
            if (x11 == x2) break;
        }
        x12 = x0 + 0x28;
        x14 -= 0x40;
        x14 += x15;
        sub_420(x0, xzr);
        x13 += x11;
        x1 = x14 - 1;
        if (x14 != 0) {
            x0 = 0;
            while (true) {
                w3 = *(void*)(x13 + x0);
                *(void*)(x12 + x0) = w3;
                x0 += 1;
                if (x1 == x0) break;
            }
        }
        return x0;
    } else {
        x1 = x14 - 1;
        x0 = 0;
        while (true) {
            w3 = *(void*)(x13 + x0);
            *(void*)(x12 + x0) = w3;
            x0 += 1;
            if (x1 == x0) break;
        }
        return x0;
    }
}

