package c.l.c;

import com.ludo.controller.MainActivity;

/* loaded from: classes.dex */
public final class cw implements Runnable {
    final /* synthetic */ String a;
    final /* synthetic */ int b;

    /* renamed from: c, reason: collision with root package name */
    final /* synthetic */ MainActivity f26c;

    public cw(MainActivity mainActivity, String str, int i) {
        this.f26c = mainActivity;
        this.a = str;
        this.b = i;
    }

    /* JADX WARN: Incorrect condition in loop: B:40:0x00c9 */
    /* JADX WARN: Incorrect condition in loop: B:62:0x01a0 */
    /* JADX WARN: Removed duplicated region for block: B:140:0x01f3  */
    /* JADX WARN: Removed duplicated region for block: B:178:0x02fc  */
    /* JADX WARN: Removed duplicated region for block: B:189:0x0306 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:41:0x00cb  */
    @Override // java.lang.Runnable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void run() {
        /*
            Method dump skipped, instructions count: 1241
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: c.l.c.cw.run():void");
    }
}
