package c.l.c;

import com.ludo.controller.MainActivity;

/* loaded from: classes.dex */
public final class dt implements Runnable {
    final /* synthetic */ long a;
    final /* synthetic */ long b;

    /* renamed from: c, reason: collision with root package name */
    final /* synthetic */ boolean f34c;
    final /* synthetic */ boolean d;
    final /* synthetic */ String e;
    final /* synthetic */ String f;
    final /* synthetic */ String g;
    final /* synthetic */ String h;
    final /* synthetic */ String i;
    final /* synthetic */ MainActivity j;

    public dt(MainActivity mainActivity, long j, long j2, boolean z, boolean z2, String str, String str2, String str3, String str4, String str5) {
        this.j = mainActivity;
        this.a = j;
        this.b = j2;
        this.f34c = z;
        this.d = z2;
        this.e = str;
        this.f = str2;
        this.g = str3;
        this.h = str4;
        this.i = str5;
    }

    /* JADX WARN: Removed duplicated region for block: B:279:0x01f9  */
    /* JADX WARN: Removed duplicated region for block: B:282:0x01f2  */
    /* JADX WARN: Removed duplicated region for block: B:36:0x00c8  */
    /* JADX WARN: Removed duplicated region for block: B:47:0x00e3  */
    /* JADX WARN: Removed duplicated region for block: B:50:0x00e9 A[Catch: Throwable -> 0x0216, TryCatch #0 {Throwable -> 0x0216, blocks: (B:285:0x009a, B:287:0x00a2, B:29:0x00ac, B:31:0x00b4, B:34:0x00bc, B:40:0x00cf, B:42:0x00d3, B:44:0x00dd, B:48:0x00e5, B:50:0x00e9, B:52:0x0107, B:54:0x0111, B:55:0x011c, B:57:0x0120, B:58:0x0127, B:60:0x012b, B:62:0x012f, B:64:0x0137, B:65:0x013b, B:67:0x0155, B:68:0x015c, B:70:0x0160, B:71:0x0167, B:73:0x016b, B:75:0x0173, B:76:0x0175, B:78:0x0182, B:79:0x018c, B:85:0x01ff, B:87:0x0205, B:89:0x0212, B:90:0x0220, B:92:0x0227, B:93:0x022e, B:95:0x0236, B:97:0x0460, B:99:0x0468, B:100:0x0241, B:102:0x024c, B:103:0x024e, B:105:0x025d, B:107:0x0262, B:109:0x026a, B:110:0x0497, B:111:0x0278, B:113:0x027c, B:115:0x0284, B:117:0x028e, B:119:0x0298, B:120:0x029e, B:122:0x02aa, B:124:0x02b2, B:125:0x02b9, B:127:0x02bd, B:130:0x02c6, B:132:0x02ce, B:134:0x02d2, B:136:0x02dc, B:140:0x02e7, B:141:0x02ea, B:145:0x02f1, B:148:0x02fb, B:150:0x0303, B:152:0x030b, B:153:0x04b2, B:154:0x0311, B:155:0x0316, B:157:0x031a, B:161:0x0333, B:162:0x0335, B:168:0x0349, B:171:0x0353, B:173:0x035b, B:176:0x0363, B:178:0x036b, B:181:0x0373, B:183:0x0377, B:189:0x0387, B:191:0x038f, B:193:0x0397, B:208:0x03bc, B:211:0x03d1, B:214:0x03d8, B:216:0x03e7, B:218:0x04dc, B:220:0x04e0, B:222:0x04e8, B:227:0x04b7, B:229:0x04bf, B:232:0x03ec, B:235:0x03fa, B:237:0x0400, B:239:0x0404, B:241:0x040c, B:243:0x0416, B:244:0x0420, B:245:0x0422, B:247:0x0426, B:248:0x042b, B:250:0x042f, B:251:0x0434, B:253:0x044c, B:254:0x0456, B:259:0x04f5, B:261:0x04fb, B:264:0x04ae, B:267:0x04a7, B:269:0x046d, B:271:0x0475, B:272:0x047a, B:274:0x0482, B:275:0x0487, B:277:0x048f, B:278:0x023e), top: B:284:0x009a }] */
    /* JADX WARN: Removed duplicated region for block: B:90:0x0220 A[Catch: Throwable -> 0x0216, TryCatch #0 {Throwable -> 0x0216, blocks: (B:285:0x009a, B:287:0x00a2, B:29:0x00ac, B:31:0x00b4, B:34:0x00bc, B:40:0x00cf, B:42:0x00d3, B:44:0x00dd, B:48:0x00e5, B:50:0x00e9, B:52:0x0107, B:54:0x0111, B:55:0x011c, B:57:0x0120, B:58:0x0127, B:60:0x012b, B:62:0x012f, B:64:0x0137, B:65:0x013b, B:67:0x0155, B:68:0x015c, B:70:0x0160, B:71:0x0167, B:73:0x016b, B:75:0x0173, B:76:0x0175, B:78:0x0182, B:79:0x018c, B:85:0x01ff, B:87:0x0205, B:89:0x0212, B:90:0x0220, B:92:0x0227, B:93:0x022e, B:95:0x0236, B:97:0x0460, B:99:0x0468, B:100:0x0241, B:102:0x024c, B:103:0x024e, B:105:0x025d, B:107:0x0262, B:109:0x026a, B:110:0x0497, B:111:0x0278, B:113:0x027c, B:115:0x0284, B:117:0x028e, B:119:0x0298, B:120:0x029e, B:122:0x02aa, B:124:0x02b2, B:125:0x02b9, B:127:0x02bd, B:130:0x02c6, B:132:0x02ce, B:134:0x02d2, B:136:0x02dc, B:140:0x02e7, B:141:0x02ea, B:145:0x02f1, B:148:0x02fb, B:150:0x0303, B:152:0x030b, B:153:0x04b2, B:154:0x0311, B:155:0x0316, B:157:0x031a, B:161:0x0333, B:162:0x0335, B:168:0x0349, B:171:0x0353, B:173:0x035b, B:176:0x0363, B:178:0x036b, B:181:0x0373, B:183:0x0377, B:189:0x0387, B:191:0x038f, B:193:0x0397, B:208:0x03bc, B:211:0x03d1, B:214:0x03d8, B:216:0x03e7, B:218:0x04dc, B:220:0x04e0, B:222:0x04e8, B:227:0x04b7, B:229:0x04bf, B:232:0x03ec, B:235:0x03fa, B:237:0x0400, B:239:0x0404, B:241:0x040c, B:243:0x0416, B:244:0x0420, B:245:0x0422, B:247:0x0426, B:248:0x042b, B:250:0x042f, B:251:0x0434, B:253:0x044c, B:254:0x0456, B:259:0x04f5, B:261:0x04fb, B:264:0x04ae, B:267:0x04a7, B:269:0x046d, B:271:0x0475, B:272:0x047a, B:274:0x0482, B:275:0x0487, B:277:0x048f, B:278:0x023e), top: B:284:0x009a }] */
    @Override // java.lang.Runnable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void run() {
        /*
            Method dump skipped, instructions count: 1294
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: c.l.c.dt.run():void");
    }
}
