package c.l.c;

import com.ludo.controller.MainActivity;

/* loaded from: classes.dex */
public final class di implements Runnable {
    final /* synthetic */ String a;
    final /* synthetic */ long b;

    /* renamed from: c, reason: collision with root package name */
    final /* synthetic */ MainActivity f32c;

    public di(MainActivity mainActivity, String str, long j) {
        this.f32c = mainActivity;
        this.a = str;
        this.b = j;
    }

    /* JADX WARN: Code restructure failed: missing block: B:67:0x0137, code lost:
    
        if (r1.a == false) goto L52;
     */
    @Override // java.lang.Runnable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void run() {
        /*
            Method dump skipped, instructions count: 407
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: c.l.c.di.run():void");
    }
}
