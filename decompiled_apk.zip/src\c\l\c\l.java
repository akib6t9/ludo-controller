package c.l.c;

/* loaded from: classes.dex */
final class l implements Runnable {
    final /* synthetic */ String a;
    final /* synthetic */ String b;

    /* renamed from: c, reason: collision with root package name */
    final /* synthetic */ a f44c;

    l(a aVar, String str, String str2) {
        this.f44c = aVar;
        this.a = str;
        this.b = str2;
    }

    @Override // java.lang.Runnable
    public final void run() {
        a.a(this.f44c, this.a, this.b);
    }
}
