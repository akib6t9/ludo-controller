package com.ludo.controller;

/* loaded from: classes.dex */
public final class R {

    public final class attr {
    }

    public final class color {
        public static final int ic_launcher_background = 0x7f050000;
    }

    public final class drawable {
        public static final int icon = 0x7f020000;
    }

    public final class mipmap {
        public static final int ic_launcher = 0x7f030000;
        public static final int ic_launcher_foreground = 0x7f030001;
        public static final int ic_launcher_round = 0x7f030002;
        public static final int icon = 0x7f030003;
    }

    public final class string {
        public static final int app_name = 0x7f060000;
    }

    public final class xml {
        public static final int network_security_config = 0x7f040000;
    }
}
