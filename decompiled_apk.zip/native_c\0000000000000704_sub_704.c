// sub_704 at 0x704, from libcontroller_guard.so. Approximate pseudo-C from the built-in decompiler.
int64_t sub_704(int64_t x0, int64_t x1, int64_t x2)
{
    0 = *(uint64_t*)0xf00;
    stack_10[0] = x19; stack_10[1] = x20;
    x19 = xzr;
    0 = *(uint64_t*)0xf10;
    x3 = xzr;
    __asm("lsl x20, x3, #0x3");
    stack_20 = x21;
    x21 = sp + 0x38;
    stack_60[0] = 0; stack_60[1] = 0;
    stack_80 = x20;
    sub_880(sp + 0x88, xzr, xzr);
    x1 = xzr;
    w0 = 0x38;
    while (true) {
        __asm("lsr x2, x20, x0");
        w0 -= 8;
        *(void*)(x1) = w2;
        wzr = w0 + 8;
        if (wzr == 0) break;
    }
    w3 = 0x7f;
    x18 = sp + 0x60;
    sub_650(xzr, sp + 0x36, 1, w3);
    stack_37 = wzr;
    x0 = stack_80;
    x0 &= 0x1f8;
    if (x0 != 0x1c0) {
        x20 = sp + 0x37;
        while (true) {
            sub_650(xzr, xzr, 1);
            x0 = stack_80;
            x0 &= 0x1f8;
            if (x0 == 0x1c0) break;
        }
    }
    sub_650(xzr, xzr, 8);
    x3 = sp + 0x40;
    x1 = 1;
    while (true) {
        __asm("lsl x0, x1, #0x2");
        x1 += 1;
        x2 = x0 + x18;
        x0 = x3 + x0;
        w2 = *(void*)(x2 - 4);
        __asm("rev w2, w2");
        *(void*)(x0 - 4) = w2;
        if (x1 == 9) break;
    }
    x5 += 0xf20;
    x5 = "0123456789abcdef";
    x4 = x19 + 1;
    while (true) {
        w1 = *(void*)(x3);
        w2 = w1 & 15;
        __asm("lsr w1, w1, #0x4");
        w6 = *(void*)(x5 + x2);
        w1 = *(void*)(x5 + x1);
        *(void*)(x4 - 1) = w1;
        *(void*)(x4) = w6;
        if (x3 == x18) break;
    }
    *(void*)(x19 + 0x40) = wzr;
    x19 = stack_10[0]; x20 = stack_10[1];
    x21 = stack_20;
    return x0;
}

