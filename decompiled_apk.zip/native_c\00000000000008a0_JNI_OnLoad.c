// JNI_OnLoad at 0x8a0, from libcontroller_guard.so. Approximate pseudo-C from the built-in decompiler.
int32_t JNI_OnLoad()
{
    w0 = 6;
    w0 = 0x10000;
    return w0;
}

