// Java_com_ludo_controller_SecurityGuard_nativeGetTelegramUsername at 0x990, from libcontroller_guard.so. Approximate pseudo-C from the built-in decompiler.
int64_t Java_com_ludo_controller_SecurityGuard_nativeGetTelegramUsername(int64_t x0)
{
    x5 += 0xf20;
    x6 = x5 + 0x140;
    x3 = sp + 0x31;
    x1 = 1;
    stack_10[0] = x19; stack_10[1] = x20;
    x20 = xzr;
    w0 = 0x49;
    stack_20 = x21;
    stack_30 = w0;
    while (true) {
        x2 = x1 & 7;
        w4 = *(void*)(x1 + x6);
        x2 = x5 + x2;
        x1 += 1;
        w2 = *(void*)(x2 + 0x118);
        w2 ^= w4;
        *(void*)(x3) = w2;
        if (x1 == 0x12) break;
    }
    x19 = sp + 0x48;
    x21 = sp + 0x30;
    stack_42 = wzr;
    sub_704(xzr, x1, xzr);
    w3 = stack_48;
    x1 = 0;
    x6 = "7bc38ffad7f84d8260fa82c60727f96074e121ff2e9a2568369a2bc7dd68679b";
    w4 = 0x37;
    if (w3 != 0) {
        while (true) {
            x5 = x19 + x1;
            x1 += 1;
            if (w3 == w4) {
                w3 = *(void*)(x5 + 1);
                w4 = *(void*)(x6 + x1);
                if (w3 == 0) {
                    goto label_a48;
                } else {
                    continue;
                }
            } else {
                break;
            }
        }
        x19 = stack_10[0]; x20 = stack_10[1];
        x0 = 0;
        x21 = stack_20;
        return x0;
    } else {
        x19 = stack_10[0]; x20 = stack_10[1];
        x0 = 0;
        x21 = stack_20;
        return x0;
    }
label_a48:
    if (w4 != 0) {
        x19 = stack_10[0]; x20 = stack_10[1];
        x0 = 0;
        x21 = stack_20;
        return x0;
    } else {
        x2 = *(void*)(x20);
        (*x2)(xzr, xzr, *(void*)(x2 + 0x538));
        x19 = stack_10[0]; x20 = stack_10[1];
        x21 = stack_20;
        return x0;
    }
}

