package c.l.c;

/* loaded from: classes.dex */
final class n implements Runnable {
    final /* synthetic */ a a;

    n(a aVar) {
        this.a = aVar;
    }

    /* JADX WARN: Incorrect condition in loop: B:2:0x000a */
    @Override // java.lang.Runnable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void run() {
        /*
            r2 = this;
        L0:
            c.l.c.a r0 = r2.a
            java.util.concurrent.atomic.AtomicBoolean r0 = c.l.c.a.g(r0)
            boolean r0 = r0.get()
            if (r0 == 0) goto L24
            c.l.c.a r0 = r2.a
            java.util.concurrent.ConcurrentLinkedQueue r0 = c.l.c.a.h(r0)
            java.lang.Object r0 = r0.poll()
            org.json.JSONObject r0 = (org.json.JSONObject) r0
            if (r0 == 0) goto L24
            c.l.c.a r1 = r2.a
            java.lang.String r0 = r0.toString()
            c.l.c.a.a(r1, r0)
            goto L0
        L24:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: c.l.c.n.run():void");
    }
}
