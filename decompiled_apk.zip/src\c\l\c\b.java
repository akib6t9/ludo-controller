package c.l.c;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.util.Log;
import java.util.concurrent.atomic.AtomicBoolean;
import org.json.JSONObject;

/* loaded from: classes.dex */
final class b implements Runnable {
    final /* synthetic */ String a;
    final /* synthetic */ String b;

    /* renamed from: c, reason: collision with root package name */
    final /* synthetic */ t f6c;
    final /* synthetic */ a d;

    b(a aVar, String str, String str2, t tVar) {
        this.d = aVar;
        this.a = str;
        this.b = str2;
        this.f6c = tVar;
    }

    @Override // java.lang.Runnable
    public final void run() {
        Context context;
        String p;
        SharedPreferences a;
        SharedPreferences a2;
        SharedPreferences a3;
        SharedPreferences a4;
        AtomicBoolean atomicBoolean;
        Context unused;
        Context unused2;
        Context unused3;
        try {
            context = this.d.a;
            String str = v.c(context) + "/api/v1/pairing/pair";
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("license_key", this.a.trim());
            p = this.d.p();
            jSONObject.put("controller_device_id", p);
            jSONObject.put("pairing_code", this.b.trim());
            jSONObject.put("model", Build.MANUFACTURER + " " + Build.MODEL);
            String a5 = v.a(str, jSONObject.toString());
            if (a5 == null || a5.trim().isEmpty()) {
                a.a(this.d, this.f6c, "Connection failed: No response from licensing server", false);
            } else {
                JSONObject jSONObject2 = new JSONObject(a5);
                if (jSONObject2.optBoolean("success", false)) {
                    String string = jSONObject2.getString("access_token");
                    String string2 = jSONObject2.getString("refresh_token");
                    String string3 = jSONObject2.getString("room_id");
                    String optString = jSONObject2.optString("target_model", "Android Device");
                    unused = this.d.a;
                    a = this.d.a();
                    u.a(a, "access_token", string);
                    unused2 = this.d.a;
                    a2 = this.d.a();
                    u.a(a2, "refresh_token", string2);
                    unused3 = this.d.a;
                    a3 = this.d.a();
                    u.a(a3, "pairing_code", this.b.trim());
                    a4 = this.d.a();
                    a4.edit().putString("room_id", string3).putString("target_model", optString).apply();
                    atomicBoolean = this.d.t;
                    atomicBoolean.set(false);
                    a.a(this.d, this.f6c, string3, this.b.trim(), optString);
                    this.d.b();
                } else {
                    a.a(this.d, this.f6c, jSONObject2.optString("error", "Pairing failed"), jSONObject2.optBoolean("locked", false));
                }
            }
        } catch (Exception e) {
            Log.e("CloudSyncClient", "Pairing exception: " + e.getMessage(), e);
            a.a(this.d, this.f6c, "Pairing error: " + e.getMessage(), false);
        }
    }
}
