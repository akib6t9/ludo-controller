# APK Architecture & Extraction Summary

## 1. General Metadata
- **Package Name:** `com.ludo.controller`
- **Version Name:** `4.5-Platinum` (Version Code: `7`)
- **Target SDK Range:** Min SDK: 23 (Android 6.0), Target SDK: 30 (Android 11), Compile SDK: 29
- **Main Launcher Activity:** `com.ludo.controller.MainActivity`

---

## 2. Directory Structure
```
decompiled_apk/
├── AndroidManifest.xml                  (Original binary AXML format)
├── AndroidManifest_readable.xml         (Decoded human-readable XML)
├── classes.dex                          (Compiled Dalvik executable code)
├── resources.arsc                       (Compiled Android resource table)
├── network_security_config_readable.xml (Decoded SSL pinning configuration)
├── lib/
│   ├── arm64-v8a/
│   │   └── libcontroller_guard.so       (Native C++ protection binary)
│   └── armeabi-v7a/
│       └── libcontroller_guard.so       (Native C++ protection binary)
├── res/                                 (App drawables, icons, mipmaps, and XMLs)
└── META-INF/                            (v1, v2, v3 Signature blocks and certificates)
```

---

## 3. Core Components & Logic
- **`com.ludo.controller.MainActivity`**:
  - Handles the UI, dice control states (`LOCK_DICE`, `LAST_DICE`), and local network UDP communication (`Controller-UdpBeaconListener`, `ControllerUdpMulticast`).
- **`com.ludo.controller.SecurityGuard`**:
  - Anti-tampering, APK certificate verification (`EXPECTED_CERT_SHA256`), and hook detection (`LuckyPatcher`, `EdXposed`, `SandHook`).
  - Calls native library `libcontroller_guard.so` (`nativeVerifyOrDie`).
- **Obfuscated Helpers (`c.l.c.*`)**:
  - 140 minified utility classes supporting networking, UI listeners, and local state management.

---

## 4. Network & Authentication Endpoints
- **Cloudflare Worker API:** `https://ludo-controller-license-api.mdmuajamin.workers.dev`
- **Alternative/Mirror Domains:** `https://hajera.cfd`, `muaj.bro.bd`
- **License Routes:**
  - `POST /api/v1/license/nonce`
  - `POST /api/v1/license/activate`
  - `POST /api/v1/license/verify`
- **SSL Certificate Pinning:** Pinned SHA-256 digests in `network_security_config_readable.xml` (valid until 2029-01-01).
