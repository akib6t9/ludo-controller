package c.l.c;

import com.ludo.controller.MainActivity;

/* loaded from: classes.dex */
public final class dw implements Runnable {
    final boolean a;
    final String b;

    /* renamed from: c, reason: collision with root package name */
    final /* synthetic */ MainActivity f37c;

    public dw(MainActivity mainActivity, boolean z, String str) {
        this.f37c = mainActivity;
        this.a = z;
        this.b = str;
    }

    private void a(String str) {
        this.f37c.L = str;
        this.f37c.j();
        this.f37c.k();
    }

    /* JADX WARN: Incorrect condition in loop: B:14:0x00b7 */
    @Override // java.lang.Runnable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void run() {
        /*
            Method dump skipped, instructions count: 512
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: c.l.c.dw.run():void");
    }
}
