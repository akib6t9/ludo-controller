// sub_880 at 0x880, from libcontroller_guard.so. Approximate pseudo-C from the built-in decompiler.
void sub_880(int64_t x2)
{
    if (x2 != 0) {
        x3 = 0;
        while (true) {
            w4 = *(void*)(x1 + x3);
            *(void*)(x0 + x3) = w4;
            x3 += 1;
            if (x3 == x2) break;
        }
    }
    return;
}

