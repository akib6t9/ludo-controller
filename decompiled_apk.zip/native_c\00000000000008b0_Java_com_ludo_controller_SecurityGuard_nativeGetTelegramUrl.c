// Java_com_ludo_controller_SecurityGuard_nativeGetTelegramUrl at 0x8b0, from libcontroller_guard.so. Approximate pseudo-C from the built-in decompiler.
int64_t Java_com_ludo_controller_SecurityGuard_nativeGetTelegramUrl(int64_t x0)
{
    x5 += 0xf20;
    x6 = x5 + 0x120;
    x3 = sp + 0x39;
    x1 = 1;
    stack_10[0] = x19; stack_10[1] = x20;
    x20 = xzr;
    w0 = 0x68;
    stack_20 = x21;
    stack_38 = w0;
    while (true) {
        x2 = x1 & 7;
        w4 = *(void*)(x1 + x6);
        x2 = x5 + x2;
        x1 += 1;
        w2 = *(void*)(x2 + 0x118);
        w2 ^= w4;
        *(void*)(x3) = w2;
        if (x1 == 0x1f) break;
    }
    x19 = sp + 0x58;
    x21 = sp + 0x38;
    stack_57 = wzr;
    sub_704(xzr, x1, xzr);
    w3 = stack_58;
    x1 = 0;
    x6 = "28260826d7c03f6dbf3b9870cb0341f706b7f176242a381eeb350969bcc9719f";
    w4 = 0x32;
    if (w3 != 0) {
        while (true) {
            x5 = x19 + x1;
            x1 += 1;
            if (w3 == w4) {
                w3 = *(void*)(x5 + 1);
                w4 = *(void*)(x6 + x1);
                if (w3 == 0) {
                    goto label_968;
                } else {
                    continue;
                }
            } else {
                break;
            }
        }
        x19 = stack_10[0]; x20 = stack_10[1];
        x0 = 0;
        x21 = stack_20;
        return x0;
    } else {
        x19 = stack_10[0]; x20 = stack_10[1];
        x0 = 0;
        x21 = stack_20;
        return x0;
    }
label_968:
    if (w4 != 0) {
        x19 = stack_10[0]; x20 = stack_10[1];
        x0 = 0;
        x21 = stack_20;
        return x0;
    } else {
        x2 = *(void*)(x20);
        (*x2)(xzr, xzr, *(void*)(x2 + 0x538));
        x19 = stack_10[0]; x20 = stack_10[1];
        x21 = stack_20;
        return x0;
    }
}

