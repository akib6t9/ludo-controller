package c.l.c;

import com.ludo.controller.MainActivity;

/* loaded from: classes.dex */
public final class dl implements Runnable {
    final /* synthetic */ MainActivity a;

    public dl(MainActivity mainActivity) {
        this.a = mainActivity;
    }

    /* JADX WARN: Incorrect condition in loop: B:9:0x0044 */
    @Override // java.lang.Runnable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void run() {
        /*
            Method dump skipped, instructions count: 257
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: c.l.c.dl.run():void");
    }
}
