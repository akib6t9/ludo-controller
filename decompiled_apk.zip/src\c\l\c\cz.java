package c.l.c;

import com.ludo.controller.MainActivity;

/* loaded from: classes.dex */
public final class cz implements Runnable {
    final /* synthetic */ String a;
    final /* synthetic */ String b;

    /* renamed from: c, reason: collision with root package name */
    final /* synthetic */ String f27c;
    final /* synthetic */ String d;
    final /* synthetic */ int e;
    final /* synthetic */ String f;
    final /* synthetic */ String g;
    final /* synthetic */ String h;
    final /* synthetic */ String i;
    final /* synthetic */ long j;
    final /* synthetic */ long k;
    final /* synthetic */ boolean l;
    final /* synthetic */ boolean m;
    final /* synthetic */ String n;
    final /* synthetic */ int[] o;
    final /* synthetic */ boolean p;
    final /* synthetic */ int q;
    final /* synthetic */ String r;
    final /* synthetic */ String s;
    final /* synthetic */ MainActivity t;

    public cz(MainActivity mainActivity, String str, String str2, String str3, String str4, int i, String str5, String str6, String str7, String str8, long j, long j2, boolean z, boolean z2, String str9, int[] iArr, boolean z3, int i2, String str10, String str11) {
        this.t = mainActivity;
        this.a = str;
        this.b = str2;
        this.f27c = str3;
        this.d = str4;
        this.e = i;
        this.f = str5;
        this.g = str6;
        this.h = str7;
        this.i = str8;
        this.j = j;
        this.k = j2;
        this.l = z;
        this.m = z2;
        this.n = str9;
        this.o = iArr;
        this.p = z3;
        this.q = i2;
        this.r = str10;
        this.s = str11;
    }

    /* JADX WARN: Removed duplicated region for block: B:95:0x023d  */
    /* JADX WARN: Removed duplicated region for block: B:97:0x0240  */
    @Override // java.lang.Runnable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void run() {
        /*
            Method dump skipped, instructions count: 1359
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: c.l.c.cz.run():void");
    }
}
