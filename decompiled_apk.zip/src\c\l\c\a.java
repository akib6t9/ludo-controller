package c.l.c;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Base64;
import android.util.Log;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Socket;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import javax.net.ssl.SSLParameters;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import org.json.JSONObject;

/* loaded from: classes.dex */
public class a {
    private static final String b = "CloudSyncClient";

    /* renamed from: c, reason: collision with root package name */
    private static final String f0c = "ludo_cloud_sync_prefs";
    private static final String d = "access_token";
    private static final String e = "refresh_token";
    private static final String f = "room_id";
    private static final String g = "pairing_code";
    private static final String h = "target_model";
    private static final long i = 45;
    private static final long j = 1000;
    private static final long k = 30000;
    private static volatile a l;
    final Context a;
    private volatile s u;
    private volatile Socket v;
    private volatile OutputStream w;
    private volatile InputStream x;
    private volatile ScheduledFuture y;
    private volatile ScheduledFuture z;
    private volatile int A = 0;
    private volatile boolean B = false;
    private volatile int C = -1;
    private final Handler m = new Handler(Looper.getMainLooper());
    private final ExecutorService n = Executors.newCachedThreadPool();
    private final ScheduledExecutorService o = Executors.newSingleThreadScheduledExecutor();
    private final ConcurrentLinkedQueue p = new ConcurrentLinkedQueue();
    private final AtomicInteger q = new AtomicInteger(1);
    private final AtomicBoolean r = new AtomicBoolean(false);
    private final AtomicBoolean s = new AtomicBoolean(false);
    private final AtomicBoolean t = new AtomicBoolean(false);

    private a(Context context) {
        this.a = context;
    }

    private static a a(Context context) {
        if (l == null) {
            synchronized (a.class) {
                if (l == null) {
                    l = new a(context.getApplicationContext());
                }
            }
        }
        return l;
    }

    private void a(int i2) {
        if (i2 <= 0 || i2 > 6 || i2 == this.C) {
            return;
        }
        this.C = i2;
        try {
            int andIncrement = this.q.getAndIncrement();
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("t", "cmd");
            jSONObject.put("a", "set_dice");
            jSONObject.put("v", i2);
            jSONObject.put("seq", andIncrement);
            jSONObject.put("ts", System.currentTimeMillis());
            a(jSONObject);
        } catch (Exception e2) {
            Log.e(b, "Error formatting dice command: " + e2.getMessage());
        }
    }

    private void a(int i2, boolean z, boolean z2) {
        this.m.post(new e(this, i2, z, z2));
    }

    private void a(int i2, byte[] bArr) {
        switch (i2) {
            case 1:
                a(new String(bArr, StandardCharsets.UTF_8));
                break;
            case 8:
                n();
                break;
            case 9:
                b(10, bArr);
                break;
        }
    }

    static /* synthetic */ void a(a aVar, t tVar, String str, String str2, String str3) {
        if (tVar != null) {
            aVar.m.post(new i(aVar, tVar, str, str2, str3));
        }
    }

    static /* synthetic */ void a(a aVar, t tVar, String str, boolean z) {
        if (tVar != null) {
            aVar.m.post(new j(aVar, tVar, str, z));
        }
    }

    static /* synthetic */ void a(a aVar, String str, String str2) {
        Socket socket;
        try {
            URI create = URI.create(v.c(aVar.a));
            boolean z = "http".equalsIgnoreCase(create.getScheme()) ? false : true;
            String host = create.getHost();
            int port = create.getPort() != -1 ? create.getPort() : z ? 443 : 80;
            if (z) {
                socket = ((SSLSocketFactory) SSLSocketFactory.getDefault()).createSocket(host, port);
                SSLSocket sSLSocket = (SSLSocket) socket;
                SSLParameters sSLParameters = sSLSocket.getSSLParameters();
                sSLParameters.setEndpointIdentificationAlgorithm("HTTPS");
                sSLSocket.setSSLParameters(sSLParameters);
                sSLSocket.startHandshake();
                v.a(sSLSocket.getSession().getPeerCertificates());
            } else {
                socket = new Socket(host, port);
            }
            socket.setTcpNoDelay(true);
            socket.setKeepAlive(true);
            socket.setSoTimeout(0);
            OutputStream outputStream = socket.getOutputStream();
            InputStream inputStream = socket.getInputStream();
            byte[] bArr = new byte[16];
            new SecureRandom().nextBytes(bArr);
            outputStream.write(("GET " + "/api/v1/sync/ws?room=".concat(String.valueOf(Uri.encode(str2 != null ? str2.trim() : ""))) + " HTTP/1.1\r\nHost: " + host + ((port == 80 || port == 443) ? "" : ":".concat(String.valueOf(port))) + "\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: " + Base64.encodeToString(bArr, 2) + "\r\nSec-WebSocket-Version: 13\r\nAuthorization: Bearer " + str + "\r\nSec-WebSocket-Protocol: " + str + "\r\nOrigin: https://" + host + "\r\n\r\n").getBytes(StandardCharsets.US_ASCII));
            outputStream.flush();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, StandardCharsets.US_ASCII));
            String readLine = bufferedReader.readLine();
            if (readLine == null) {
                throw new Exception("Handshake failed: empty response from server");
            }
            if (readLine.contains("101") || readLine.contains("200")) {
                while (true) {
                    String readLine2 = bufferedReader.readLine();
                    if (readLine2 == null || readLine2.isEmpty()) {
                        break;
                    } else if (readLine2.toLowerCase().contains("x-quota-fallback")) {
                        aVar.t.set(true);
                    }
                }
                synchronized (aVar) {
                    aVar.v = socket;
                    aVar.w = outputStream;
                    aVar.x = inputStream;
                    aVar.r.set(true);
                    aVar.s.set(false);
                    aVar.A = 0;
                }
                aVar.b(str2, "normal");
                aVar.k();
                aVar.y = aVar.o.scheduleWithFixedDelay(new o(aVar), i, i, TimeUnit.SECONDS);
                aVar.n.execute(new n(aVar));
                aVar.a(inputStream);
                return;
            }
            if (readLine.contains("429")) {
                aVar.t.set(true);
                aVar.c("Daily free quota (100k requests) exceeded.", "18080");
                throw new Exception("Quota limit exceeded (HTTP 429)");
            }
            if (!readLine.contains("401")) {
                throw new Exception("WebSocket Handshake rejected: ".concat(String.valueOf(readLine)));
            }
            try {
                String b2 = u.b(aVar.a(), e, "");
                if (!b2.isEmpty()) {
                    String c2 = v.c(aVar.a);
                    JSONObject jSONObject = new JSONObject();
                    jSONObject.put(e, b2);
                    jSONObject.put("device_id", aVar.p());
                    String a = v.a(c2 + "/api/v1/pairing/refresh", jSONObject.toString());
                    if (a != null) {
                        JSONObject jSONObject2 = new JSONObject(a);
                        if (jSONObject2.optBoolean("success", false)) {
                            u.a(aVar.a(), d, jSONObject2.getString(d));
                            String optString = jSONObject2.optString(e, "");
                            if (!optString.isEmpty()) {
                                u.a(aVar.a(), e, optString);
                            }
                        }
                    }
                }
            } catch (Exception e2) {
            }
            throw new Exception("Token expired (HTTP 401)");
        } catch (Exception e3) {
            Log.w(b, "WebSocket connection error: " + e3.getMessage());
            e3.getMessage();
            aVar.n();
            aVar.l();
        }
    }

    private void a(s sVar) {
        this.u = sVar;
    }

    private void a(t tVar, String str, String str2, String str3) {
        if (tVar == null) {
            return;
        }
        this.m.post(new i(this, tVar, str, str2, str3));
    }

    private void a(t tVar, String str, boolean z) {
        if (tVar == null) {
            return;
        }
        this.m.post(new j(this, tVar, str, z));
    }

    private void a(InputStream inputStream) {
        int read;
        int read2;
        long j2;
        byte[] bArr;
        int read3;
        while (this.r.get() && (read = inputStream.read()) != -1 && (read2 = inputStream.read()) != -1) {
            try {
                int i2 = read & 15;
                boolean z = (read2 & 128) != 0;
                long j3 = read2 & 127;
                if (j3 == 126) {
                    j2 = ((inputStream.read() & 255) << 8) | (inputStream.read() & 255);
                } else {
                    if (j3 == 127) {
                        inputStream.read(new byte[8]);
                        j3 = 0;
                        for (int i3 = 0; i3 < 8; i3++) {
                            j3 = (j3 << 8) | (r4[i3] & 255);
                        }
                    }
                    j2 = j3;
                }
                if (z) {
                    byte[] bArr2 = new byte[4];
                    inputStream.read(bArr2);
                    bArr = bArr2;
                } else {
                    bArr = null;
                }
                byte[] bArr3 = new byte[(int) j2];
                int i4 = 0;
                while (i4 < j2 && (read3 = inputStream.read(bArr3, i4, ((int) j2) - i4)) != -1) {
                    i4 += read3;
                }
                if (z && bArr != null) {
                    for (int i5 = 0; i5 < bArr3.length; i5++) {
                        bArr3[i5] = (byte) (bArr3[i5] ^ bArr[i5 % 4]);
                    }
                }
                switch (i2) {
                    case 1:
                        a(new String(bArr3, StandardCharsets.UTF_8));
                        break;
                    case 8:
                        n();
                        break;
                    case 9:
                        b(10, bArr3);
                        break;
                }
            } catch (Exception e2) {
                new StringBuilder("Frame reader closed: ").append(e2.getMessage());
                return;
            } finally {
                n();
                l();
            }
        }
    }

    private void a(Runnable runnable) {
        h();
        this.n.execute(new k(this, runnable));
    }

    private void a(String str) {
        try {
            JSONObject jSONObject = new JSONObject(str);
            String optString = jSONObject.optString("t", "");
            if ("welcome".equals(optString)) {
                b(f(), jSONObject.optString("quota_mode", "normal"));
            } else if ("presence".equals(optString)) {
                a(jSONObject.optString("role", ""), jSONObject.optString("deviceId", ""), "online".equals(jSONObject.optString("status", "")));
            } else if ("ack".equals(optString)) {
                a(jSONObject.optInt("seq", 0), jSONObject.optBoolean("delivered", false), jSONObject.optBoolean("dup", false));
            } else if ("telemetry".equals(optString) || "state".equals(optString)) {
                b(jSONObject);
            } else if ("quota_exceeded".equals(optString)) {
                this.t.set(true);
                c(jSONObject.optString("error", "Daily quota reached"), "18080");
            }
        } catch (Exception e2) {
            Log.w(b, "Failed parsing server message: ".concat(String.valueOf(str)));
        }
    }

    private void a(String str, String str2) {
        Socket socket;
        try {
            URI create = URI.create(v.c(this.a));
            boolean z = "http".equalsIgnoreCase(create.getScheme()) ? false : true;
            String host = create.getHost();
            int port = create.getPort() != -1 ? create.getPort() : z ? 443 : 80;
            if (z) {
                socket = ((SSLSocketFactory) SSLSocketFactory.getDefault()).createSocket(host, port);
                SSLSocket sSLSocket = (SSLSocket) socket;
                SSLParameters sSLParameters = sSLSocket.getSSLParameters();
                sSLParameters.setEndpointIdentificationAlgorithm("HTTPS");
                sSLSocket.setSSLParameters(sSLParameters);
                sSLSocket.startHandshake();
                v.a(sSLSocket.getSession().getPeerCertificates());
            } else {
                socket = new Socket(host, port);
            }
            socket.setTcpNoDelay(true);
            socket.setKeepAlive(true);
            socket.setSoTimeout(0);
            OutputStream outputStream = socket.getOutputStream();
            InputStream inputStream = socket.getInputStream();
            byte[] bArr = new byte[16];
            new SecureRandom().nextBytes(bArr);
            outputStream.write(("GET " + "/api/v1/sync/ws?room=".concat(String.valueOf(Uri.encode(str2 != null ? str2.trim() : ""))) + " HTTP/1.1\r\nHost: " + host + ((port == 80 || port == 443) ? "" : ":".concat(String.valueOf(port))) + "\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: " + Base64.encodeToString(bArr, 2) + "\r\nSec-WebSocket-Version: 13\r\nAuthorization: Bearer " + str + "\r\nSec-WebSocket-Protocol: " + str + "\r\nOrigin: https://" + host + "\r\n\r\n").getBytes(StandardCharsets.US_ASCII));
            outputStream.flush();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, StandardCharsets.US_ASCII));
            String readLine = bufferedReader.readLine();
            if (readLine == null) {
                throw new Exception("Handshake failed: empty response from server");
            }
            if (readLine.contains("101") || readLine.contains("200")) {
                while (true) {
                    String readLine2 = bufferedReader.readLine();
                    if (readLine2 == null || readLine2.isEmpty()) {
                        break;
                    } else if (readLine2.toLowerCase().contains("x-quota-fallback")) {
                        this.t.set(true);
                    }
                }
                synchronized (this) {
                    this.v = socket;
                    this.w = outputStream;
                    this.x = inputStream;
                    this.r.set(true);
                    this.s.set(false);
                    this.A = 0;
                }
                b(str2, "normal");
                k();
                this.y = this.o.scheduleWithFixedDelay(new o(this), i, i, TimeUnit.SECONDS);
                this.n.execute(new n(this));
                a(inputStream);
                return;
            }
            if (readLine.contains("429")) {
                this.t.set(true);
                c("Daily free quota (100k requests) exceeded.", "18080");
                throw new Exception("Quota limit exceeded (HTTP 429)");
            }
            if (!readLine.contains("401")) {
                throw new Exception("WebSocket Handshake rejected: ".concat(String.valueOf(readLine)));
            }
            try {
                String b2 = u.b(a(), e, "");
                if (!b2.isEmpty()) {
                    String c2 = v.c(this.a);
                    JSONObject jSONObject = new JSONObject();
                    jSONObject.put(e, b2);
                    jSONObject.put("device_id", p());
                    String a = v.a(c2 + "/api/v1/pairing/refresh", jSONObject.toString());
                    if (a != null) {
                        JSONObject jSONObject2 = new JSONObject(a);
                        if (jSONObject2.optBoolean("success", false)) {
                            u.a(a(), d, jSONObject2.getString(d));
                            String optString = jSONObject2.optString(e, "");
                            if (!optString.isEmpty()) {
                                u.a(a(), e, optString);
                            }
                        }
                    }
                }
            } catch (Exception e2) {
            }
            throw new Exception("Token expired (HTTP 401)");
        } catch (Exception e3) {
            Log.w(b, "WebSocket connection error: " + e3.getMessage());
            e3.getMessage();
            n();
            l();
        }
    }

    private void a(String str, String str2, t tVar) {
        this.n.execute(new b(this, str, str2, tVar));
    }

    private void a(String str, String str2, boolean z) {
        this.m.post(new d(this, str, str2, z));
    }

    private void a(String str, boolean z) {
        try {
            int andIncrement = this.q.getAndIncrement();
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("t", "cmd");
            jSONObject.put("a", "lock");
            jSONObject.put("c", str);
            jSONObject.put("v", z ? 1 : 0);
            jSONObject.put("seq", andIncrement);
            a(jSONObject);
        } catch (Exception e2) {
            Log.e(b, "Error formatting lock command: " + e2.getMessage());
        }
    }

    private void a(JSONObject jSONObject) {
        if (this.r.get()) {
            if (b(jSONObject.toString())) {
                return;
            }
            this.p.offer(jSONObject);
        } else {
            this.p.offer(jSONObject);
            if (this.B || this.s.get()) {
                return;
            }
            b();
        }
    }

    private void b(String str, String str2) {
        this.m.post(new r(this, str, str2));
    }

    private void b(JSONObject jSONObject) {
        this.m.post(new f(this, jSONObject));
    }

    private synchronized boolean b(int i2, byte[] bArr) {
        boolean z = false;
        synchronized (this) {
            try {
                if (this.w != null && this.v != null && !this.v.isClosed()) {
                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                    byteArrayOutputStream.write((i2 & 15) | 128);
                    int length = bArr != null ? bArr.length : 0;
                    if (length <= 125) {
                        byteArrayOutputStream.write(length | 128);
                    } else if (length <= 65535) {
                        byteArrayOutputStream.write(254);
                        byteArrayOutputStream.write((length >> 8) & 255);
                        byteArrayOutputStream.write(length & 255);
                    } else {
                        byteArrayOutputStream.write(255);
                        for (int i3 = 7; i3 >= 0; i3--) {
                            byteArrayOutputStream.write((length >> (i3 * 8)) & 255);
                        }
                    }
                    byte[] bArr2 = new byte[4];
                    new SecureRandom().nextBytes(bArr2);
                    byteArrayOutputStream.write(bArr2);
                    if (bArr != null) {
                        byte[] bArr3 = new byte[bArr.length];
                        for (int i4 = 0; i4 < bArr.length; i4++) {
                            bArr3[i4] = (byte) (bArr[i4] ^ bArr2[i4 % 4]);
                        }
                        byteArrayOutputStream.write(bArr3);
                    }
                    this.w.write(byteArrayOutputStream.toByteArray());
                    this.w.flush();
                    z = true;
                }
            } catch (Exception e2) {
                Log.w(b, "Send frame failed: " + e2.getMessage());
            }
        }
        return z;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public synchronized boolean b(String str) {
        return b(1, str.getBytes(StandardCharsets.UTF_8));
    }

    private void c(String str) {
        this.m.post(new c(this, str, true));
    }

    private void c(String str, String str2) {
        this.m.post(new g(this, str, str2));
    }

    private boolean c() {
        return this.r.get();
    }

    private void d(String str) {
        this.m.post(new h(this, str));
    }

    private boolean d() {
        return this.t.get();
    }

    private String e() {
        return u.b(a(), g, "");
    }

    private String f() {
        return a().getString(f, "");
    }

    private String g() {
        return a().getString(h, "Android Device");
    }

    private synchronized void h() {
        this.B = true;
        this.s.set(false);
        k();
        m();
        this.n.execute(new m(this));
    }

    private void i() {
        this.n.execute(new n(this));
    }

    private void j() {
        k();
        this.y = this.o.scheduleWithFixedDelay(new o(this), i, i, TimeUnit.SECONDS);
    }

    private void k() {
        if (this.y != null) {
            this.y.cancel(true);
            this.y = null;
        }
    }

    private void l() {
        if (this.B || this.t.get()) {
            return;
        }
        m();
        this.A++;
        long min = (long) Math.min(30000.0d, 1000.0d * Math.pow(1.8d, Math.min(this.A, 6)));
        long max = Math.max(j, min + ((long) ((Math.random() - 0.5d) * min * 0.3d)));
        c("Connection lost. Reconnecting in " + (max / j) + "s...");
        this.z = this.o.schedule(new p(this), max, TimeUnit.MILLISECONDS);
    }

    private void m() {
        if (this.z != null) {
            this.z.cancel(true);
            this.z = null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public synchronized void n() {
        this.r.set(false);
        this.s.set(false);
        k();
        try {
            if (this.v != null && !this.v.isClosed()) {
                this.v.close();
            }
        } catch (Exception e2) {
        }
        this.v = null;
        this.w = null;
        this.x = null;
    }

    private void o() {
        try {
            String b2 = u.b(a(), e, "");
            if (b2.isEmpty()) {
                return;
            }
            String c2 = v.c(this.a);
            JSONObject jSONObject = new JSONObject();
            jSONObject.put(e, b2);
            jSONObject.put("device_id", p());
            String a = v.a(c2 + "/api/v1/pairing/refresh", jSONObject.toString());
            if (a != null) {
                JSONObject jSONObject2 = new JSONObject(a);
                if (jSONObject2.optBoolean("success", false)) {
                    u.a(a(), d, jSONObject2.getString(d));
                    String optString = jSONObject2.optString(e, "");
                    if (optString.isEmpty()) {
                        return;
                    }
                    u.a(a(), e, optString);
                }
            }
        } catch (Exception e2) {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public String p() {
        try {
            String string = Settings.Secure.getString(this.a.getContentResolver(), "android_id");
            if (string != null && !string.trim().isEmpty()) {
                return "ctrl_" + string.trim();
            }
        } catch (Exception e2) {
        }
        return "ctrl_" + Build.SERIAL;
    }

    private void q() {
        this.m.post(new q(this));
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final SharedPreferences a() {
        return this.a.getSharedPreferences(f0c, 0);
    }

    public final synchronized void b() {
        this.B = false;
        if (!this.r.get() && !this.s.get()) {
            String b2 = u.b(a(), d, "");
            String string = a().getString(f, "");
            if (b2.isEmpty() || string.isEmpty()) {
                this.m.post(new h(this, "Device not paired yet. Please enter pairing code."));
            } else {
                this.s.set(true);
                this.m.post(new q(this));
                this.n.execute(new l(this, b2, string));
            }
        }
    }
}
