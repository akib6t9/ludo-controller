// Java_com_ludo_controller_SecurityGuard_nativeVerifyOrDie at 0xa70, from libcontroller_guard.so. Approximate pseudo-C from the built-in decompiler.
int64_t Java_com_ludo_controller_SecurityGuard_nativeVerifyOrDie(int64_t x0, int64_t x3)
{
    x8 = 0x38;
    x1 = "/proc/self/status";
    x2 = 0;
    stack_10[0] = x19; stack_10[1] = x20;
    x20 = xzr;
    x19 = xzr;
    x0 = 0x63;
    __asm("svc #0x0");
    if (((w0 >> 31) & 1) != 0) {
label_b38:
        x2 = *(void*)(x20);
        x0 = (*x2)(xzr, "bin/mt/apksignaturekiller/Hook", *(void*)(x2 + 0x30));
        if (x0 == 0) {
label_b7c:
            x1 = *(void*)(x20);
            (*x1)(xzr, *(void*)(x1 + 0x88));
            x2 = *(void*)(x20);
            x0 = (*x2)(xzr, "bin/mt/signature/Killer", *(void*)(x2 + 0x30));
            x1 = xzr;
            if (x0 == 0) {
                x1 = *(void*)(x20);
                (*x1)(xzr, *(void*)(x1 + 0x88));
                if (x19 == 0) {
label_ca0:
                    x4 += 0xf20;
                    x5 = x4 + 0x140;
                    x2 = sp + 0x29;
                    w0 = 0x49;
                    x1 = 1;
                    stack_28 = w0;
                    while (true) {
                        x0 = x1 & 7;
                        w3 = *(void*)(x1 + x5);
                        x0 = x4 + x0;
                        x1 += 1;
                        w0 = *(void*)(x0 + 0x118);
                        w0 ^= w3;
                        *(void*)(x2) = w0;
                        if (x1 == 0x12) break;
                    }
                    x19 = sp + 0x40;
                    stack_3a = wzr;
                    sub_704(sp + 0x28, x1, xzr);
                    w0 = stack_40;
                    x1 = 0;
                    x5 = "7bc38ffad7f84d8260fa82c60727f96074e121ff2e9a2568369a2bc7dd68679b";
                    w3 = 0x37;
                    if (w0 != 0) {
                        while (true) {
                            x4 = x19 + x1;
                            x1 += 1;
                            if (w0 == w3) {
                                w0 = *(void*)(x4 + 1);
                                w3 = *(void*)(x5 + x1);
                                if (w0 == 0) {
                                    goto label_d34;
                                } else {
                                    continue;
                                }
                                break;
                            } else {
                                goto label_d30;
                            }
                            break;
                        }
                    } else {
                    }
                } else {
                    x3 = *(void*)(x20);
                    x0 = (*x3)(xzr, xzr, 0, *(void*)(x3 + 0x548));
                    x10 = xzr;
                    if (x0 == 0) {
                        goto label_ca0;
                    } else {
                        x0 = sub_390(x0, "f94b0b74d94dd74f205ad0703bff8dd6c8eed4c1d8ced70d9ac889df90e2a55d");
                        if (w0 != 0) {
                            x0 = sub_390(xzr, "a32b59d8ada1e0234e230eb805d12fc92092aa338108a22360c38b2ebb698d4d");
                            x3 = *(void*)(x20);
                            w19 = wzr;
                            (*x3)(xzr, xzr, xzr, *(void*)(x3 + 0x550));
                            if (w19 != 0) {
label_b68:
                                w0 = 0;
                            } else {
                                goto label_ca0;
                            }
                        } else {
                            x3 = *(void*)(x20);
                            (*x3)(xzr, xzr, xzr, *(void*)(x3 + 0x550));
                            goto label_ca0;
                        }
                    }
                }
            } else {
                x2 = *(void*)(x20);
                (*x2)(xzr, x1, *(void*)(x2 + 0xb8));
                goto label_b68;
            }
        } else {
label_b54:
            x2 = *(void*)(x20);
            (*x2)(xzr, xzr, *(void*)(x2 + 0xb8));
            goto label_b68;
        }
    } else {
        __asm("sxtw x3, w0");
        x5 = sp + 0x40;
        x0 = xzr;
        x1 = xzr;
        x8 = 0x3f;
        x2 = 0x1ff;
        __asm("svc #0x0");
        x8 = 0x39;
        x4 = xzr;
        x1 = 0;
        x0 = xzr;
        x2 = 0;
        __asm("svc #0x0");
        if (x4 <= 0) {
            goto label_b38;
        } else {
            *(void*)(x5 + x4) = wzr;
            w0 = stack_40;
            if (w0 == 0) {
                goto label_b38;
            } else {
                x5 = sp + 0x41;
                x6 = "TracerPid:";
                while (true) {
                    w4 = *(void*)(x5 - 1);
                    x1 = 0;
                    w2 = 0x54;
                    if (w4 != 0) {
                        while (true) {
                            __asm("ccmp w4, w2, #0x0, ne");
                            if (w4 == 0) {
                                w4 = *(void*)(x5 + x1);
                                x1 += 1;
                                w2 = *(void*)(x6 + x1);
                                if (w4 == 0) break;
                                continue;
                            } else {
                                break;
                            }
                            break;
                        }
                        if (w2 == 0) {
                            goto label_bc0;
                        } else {
label_b2c:
                            w0 = *(void*)(x5);
                            if (w0 != 0) {
                                continue;
                            } else {
                                goto label_b34;
                            }
                            break;
                        }
                        break;
                    } else {
                        goto label_b2c;
                    }
                    break;
                }
            }
        }
    }
    x19 = stack_10[0]; x20 = stack_10[1];
    return x0;
label_b34:
    goto label_b38;
label_bc0:
    w1 = *(void*)(x5 + 9);
    x5 += 9;
    __asm("ccmp w1, #0x9, #0x4, ne");
    if (w1 == 0) {
        while (true) {
            w1 = *(void*)(x5 + 1);
            __asm("ccmp w1, #0x9, #0x4, ne");
            if (w1 != 0) break;
        }
    }
    w3 = w1 - 0x30;
    w0 = w3 & 0xff;
    if (w0 > 9 /* unsigned */) {
        goto label_b38;
    } else {
        w2 = 0;
        while (true) {
            w1 = *(void*)(x5 + 1);
            w2 += w2;
            w2 = w3 + w2;
            w3 = w1 - 0x30;
            w0 = w3 & 0xff;
            if (w0 > 9 /* unsigned */) break;
        }
        if (w2 > 0) {
            goto label_b68;
        } else {
            x2 = *(void*)(x20);
            x0 = (*x2)(xzr, "bin/mt/apksignaturekiller/Hook", *(void*)(x2 + 0x30));
            if (x0 != 0) {
                goto label_b54;
            } else {
                goto label_b7c;
            }
        }
    }
    x19 = stack_10[0]; x20 = stack_10[1];
    return x0;
label_d30:
    goto label_b68;
label_d34:
    __asm("cset w0, eq");
    x19 = stack_10[0]; x20 = stack_10[1];
    return x0;
}

