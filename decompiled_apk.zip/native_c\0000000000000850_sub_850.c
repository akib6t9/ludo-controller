// sub_850 at 0x850, from libcontroller_guard.so. Approximate pseudo-C from the built-in decompiler.
int64_t sub_850(int64_t x0, int64_t x2)
{
    stack_10 = x19;
    x19 = xzr;
    if (x2 != 0) {
        w1 &= 0xff;
        sub_850();
    }
    x0 = xzr;
    x19 = stack_10;
    return x0;
}

