package c.l.c;

import com.ludo.controller.MainActivity;

/* loaded from: classes.dex */
public final class ds implements Runnable {
    final /* synthetic */ MainActivity a;

    public ds(MainActivity mainActivity) {
        this.a = mainActivity;
    }

    /* JADX WARN: Code restructure failed: missing block: B:9:0x0025, code lost:
    
        r0 = r3.a.aw;
     */
    @Override // java.lang.Runnable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void run() {
        /*
            r3 = this;
            com.ludo.controller.MainActivity r0 = r3.a
            java.lang.String r0 = com.ludo.controller.MainActivity.w(r0)
            if (r0 == 0) goto L30
            boolean r1 = r0.isEmpty()
            if (r1 != 0) goto L30
            boolean r1 = com.ludo.controller.MainActivity.A(r0)
            if (r1 != 0) goto L30
            com.ludo.controller.MainActivity r1 = r3.a
            java.lang.String r1 = com.ludo.controller.MainActivity.W(r1)
            com.ludo.controller.MainActivity r2 = r3.a
            com.ludo.controller.MainActivity.e(r2, r0)
            boolean r0 = r0.equals(r1)
            if (r0 != 0) goto L30
            com.ludo.controller.MainActivity r0 = r3.a
            java.net.Socket r0 = com.ludo.controller.MainActivity.q(r0)
            if (r0 == 0) goto L30
            r0.close()     // Catch: java.lang.Throwable -> L31
        L30:
            return
        L31:
            r0 = move-exception
            goto L30
        */
        throw new UnsupportedOperationException("Method not decompiled: c.l.c.ds.run():void");
    }
}
