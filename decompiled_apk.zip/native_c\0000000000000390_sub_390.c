// sub_390 at 0x390, from libcontroller_guard.so. Approximate pseudo-C from the built-in decompiler.
int32_t sub_390(int64_t x0)
{
    w2 = *(void*)(x0);
    if (w2 != 0) {
        while (true) {
            w3 = *(void*)(x1);
            w7 = w2 - 0x41;
            w5 = w2 + 0x20;
            w6 = w3 - 0x41;
            __asm("csel w8, w5, w2, lo");
            w4 = w3 + 0x20;
            __asm("csel w4, w4, w3, lo");
            x9 = x1 + 1;
            if (w4 == w8) {
                w2 = *(void*)(x0 + 1);
                if (w2 == 0) {
                    goto label_3f0;
                } else {
                    x1 = xzr;
                    continue;
                }
            } else {
                break;
            }
        }
        w0 = wzr;
        w1 = w3 + 0x20;
        __asm("csel w3, w1, w3, lo");
        w0 -= w3;
        return w0;
    } else {
        w3 = *(void*)(x1);
        w0 = 0;
        w6 = w3 - 0x41;
        w1 = w3 + 0x20;
        __asm("csel w3, w1, w3, lo");
        w0 -= w3;
        return w0;
    }
label_3f0:
    w3 = *(void*)(x1 + 1);
    w0 = 0;
    w6 = w3 - 0x41;
    w1 = w3 + 0x20;
    __asm("csel w3, w1, w3, lo");
    w0 -= w3;
    return w0;
}

